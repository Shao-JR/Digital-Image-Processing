import numpy as np
import cv2
import matplotlib.pyplot as plt

# ---------------------- 1. 加载/生成图像 ----------------------
# 若有原始图像，直接读取；若无，用随机噪声图模拟（这里用OpenCV自带的测试图）
img = cv2.imread('hku.png', 0)  # 灰度图读取
# img = cv2.imread(cv2.samples.findFile('lena.jpg'), 0)  # 示例：用lena图（需确保路径正确）
if img is None:
    # 若找不到图，生成一个简单的测试图（比如带文字的灰度图，或随机图）
    img = np.zeros((256, 256), dtype=np.uint8)
    cv2.putText(img, 'Test Image', (50, 128), cv2.FONT_HERSHEY_SIMPLEX, 2, 255, 2)
print(f"图像尺寸: {img.shape}")

# ---------------------- 2. 生成高斯低通滤波器（退化核H） ----------------------
def generate_gaussian_lp_filter(shape, cutoff_radius):
    """生成高斯低通滤波器（频域）
    shape: 图像尺寸 (H, W)
    cutoff_radius: 截止半径（高斯分布的标准差相关）
    """
    H, W = shape
    u = np.arange(-W//2, W//2)
    v = np.arange(-H//2, H//2)
    U, V = np.meshgrid(u, v)
    D = np.sqrt(U**2 + V**2)  # 频率域的距离
    H_filter = np.exp(-(D**2) / (2 * cutoff_radius**2))  # 高斯低通：中心保留，高频衰减
    return H_filter

# 测试：生成截止半径40和110的滤波器（注意：这里先定义，后面会切换）
cutoff_radius = 40  # 可修改为110测试
H = generate_gaussian_lp_filter(img.shape, cutoff_radius)

# ---------------------- 3. 图像退化（频域操作） ----------------------
def degrade_image(img, H):
    """图像退化：原始图→傅里叶变换→乘以退化核H→逆傅里叶变换"""
    f = np.fft.fft2(img)  # 傅里叶变换（移到频域）
    f_shift = np.fft.fftshift(f)  # 移到中心（低频在中间）
    G = f_shift * H  # 频域退化（低通滤波=模糊）
    g_shift = np.fft.ifftshift(G)  # 移回原位置
    g = np.fft.ifft2(g_shift)  # 逆傅里叶变换（回到空域）
    g = np.abs(g)  # 取实部（虚部理论上为0）
    g = (g / g.max()) * 255  # 归一化到0-255
    g = g.astype(np.uint8)
    return g

# 生成退化图（用cutoff_radius=40）
degraded_img_40 = degrade_image(img, generate_gaussian_lp_filter(img.shape, 40))
# 生成退化图（用cutoff_radius=110，对比更严重的模糊？不，截止半径越大，模糊越轻！因为高斯低通的半径大，保留的高频多，模糊少）
degraded_img_110 = degrade_image(img, generate_gaussian_lp_filter(img.shape, 110))

# ---------------------- 4. 逆滤波修复（三种方案） ----------------------
def inverse_filtering(degraded_img, H, epsilon=1e-6, threshold=None, method=1):
    """逆滤波修复（三种方案可选）
    degraded_img: 退化后的图像（空域）
    H: 退化核（频域）
    epsilon: 小常数（避免除以0）
    threshold: 阈值（方案3用）
    method: 1/2/3 对应三种方案
    """
    # 1. 退化图转频域
    g = np.fft.fft2(degraded_img)
    g_shift = np.fft.fftshift(g)
    H_shift = np.fft.fftshift(H)  # 确保H也在中心（其实生成时已经是fftshift后的，这里再确认）
    
    # 2. 计算修复后的频域F_hat
    F_hat_shift = np.zeros_like(H_shift, dtype=complex)
    for i in range(H_shift.shape[0]):
        for j in range(H_shift.shape[1]):
            if method == 1:
                # 方案1: if |D(u,v)| < ε → F_hat = G/H; else → 0
                D = np.sqrt((i - H_shift.shape[0]//2)**2 + (j - H_shift.shape[1]//2)**2)
                if D < epsilon:
                    F_hat_shift[i, j] = g_shift[i, j] / (H_shift[i, j] + epsilon)  # +epsilon避免除以0
                else:
                    F_hat_shift[i, j] = 0
            elif method == 2:
                # 方案2: if |D(u,v)| < ε → F_hat = G/H; else → G
                D = np.sqrt((i - H_shift.shape[0]//2)**2 + (j - H_shift.shape[1]//2)**2)
                if D < epsilon:
                    F_hat_shift[i, j] = g_shift[i, j] / (H_shift[i, j] + epsilon)
                else:
                    F_hat_shift[i, j] = g_shift[i, j]
            elif method == 3:
                # 方案3: if ||H(u,v)|| > threshold → F_hat = G/H; else → G
                if np.abs(H_shift[i, j]) > threshold:
                    F_hat_shift[i, j] = g_shift[i, j] / (H_shift[i, j] + epsilon)
                else:
                    F_hat_shift[i, j] = g_shift[i, j]
            else:
                raise ValueError("method must be 1, 2, or 3")
    
    # 3. 逆傅里叶变换回空域
    F_hat = np.fft.ifftshift(F_hat_shift)
    f_hat = np.fft.ifft2(F_hat)
    f_hat = np.abs(f_hat)
    f_hat = (f_hat / f_hat.max()) * 255
    f_hat = f_hat.astype(np.uint8)
    return f_hat

# 定义阈值（方案3用，比如选H的最小值附近，或经验值）
threshold = 0.1  # 可调整，比如0.01或0.2

# 对degraded_img_40（截止半径40，模糊较重）用三种方案修复
restored_40_method1 = inverse_filtering(degraded_img_40, H=generate_gaussian_lp_filter(img.shape, 40), method=1)
restored_40_method2 = inverse_filtering(degraded_img_40, H=generate_gaussian_lp_filter(img.shape, 40), method=2)
restored_40_method3 = inverse_filtering(degraded_img_40, H=generate_gaussian_lp_filter(img.shape, 40), threshold=threshold, method=3)

# 对degraded_img_110（截止半径110，模糊较轻）用三种方案修复
restored_110_method1 = inverse_filtering(degraded_img_110, H=generate_gaussian_lp_filter(img.shape, 110), method=1)
restored_110_method2 = inverse_filtering(degraded_img_110, H=generate_gaussian_lp_filter(img.shape, 110), method=2)
restored_110_method3 = inverse_filtering(degraded_img_110, H=generate_gaussian_lp_filter(img.shape, 110), threshold=threshold, method=3)

# ---------------------- 5. 可视化结果 ----------------------
plt.figure(figsize=(18, 12))

# 原始图
plt.subplot(4, 4, 1)
plt.imshow(img, cmap='gray')
plt.title('Original Image')
plt.axis('off')

# 退化图（截止半径40）
plt.subplot(4, 4, 5)
plt.imshow(degraded_img_40, cmap='gray')
plt.title('Degraded (Cutoff=40)')
plt.axis('off')

# 退化图（截止半径110）
plt.subplot(4, 4, 9)
plt.imshow(degraded_img_110, cmap='gray')
plt.title('Degraded (Cutoff=110)')
plt.axis('off')

# 方案1修复（截止40）
plt.subplot(4, 4, 2)
plt.imshow(restored_40_method1, cmap='gray')
plt.title('Restored (Method1, Cutoff=40)')
plt.axis('off')

# 方案2修复（截止40）
plt.subplot(4, 4, 3)
plt.imshow(restored_40_method2, cmap='gray')
plt.title('Restored (Method2, Cutoff=40)')
plt.axis('off')

# 方案3修复（截止40）
plt.subplot(4, 4, 4)
plt.imshow(restored_40_method3, cmap='gray')
plt.title('Restored (Method3, Cutoff=40)')
plt.axis('off')

# 方案1修复（截止110）
plt.subplot(4, 4, 6)
plt.imshow(restored_110_method1, cmap='gray')
plt.title('Restored (Method1, Cutoff=110)')
plt.axis('off')

# 方案2修复（截止110）
plt.subplot(4, 4, 7)
plt.imshow(restored_110_method2, cmap='gray')
plt.title('Restored (Method2, Cutoff=110)')
plt.axis('off')

# 方案3修复（截止110）
plt.subplot(4, 4, 8)
plt.imshow(restored_110_method3, cmap='gray')
plt.title('Restored (Method3, Cutoff=110)')
plt.axis('off')

# 可选：放大局部对比（比如前100x100像素）
plt.subplot(4, 4, 13)
plt.imshow(img[:100, :100], cmap='gray')
plt.title('Original (Crop)')
plt.axis('off')

plt.subplot(4, 4, 14)
plt.imshow(degraded_img_40[:100, :100], cmap='gray')
plt.title('Degraded (Cutoff=40, Crop)')
plt.axis('off')

plt.subplot(4, 4, 15)
plt.imshow(restored_40_method2[:100, :100], cmap='gray')  # 选方案2展示
plt.title('Restored (Method2, Cutoff=40, Crop)')
plt.axis('off')

plt.subplot(4, 4, 16)
plt.imshow(restored_110_method2[:100, :100], cmap='gray')  # 选方案2展示
plt.title('Restored (Method2, Cutoff=110, Crop)')
plt.axis('off')

plt.tight_layout()
plt.show()